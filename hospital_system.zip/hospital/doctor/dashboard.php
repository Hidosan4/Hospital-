<?php
require_once '../includes/config.php';
requireRole('doctor');
$pageTitle = 'Doctor Dashboard';

$stmt = $pdo->prepare("SELECT d.id FROM doctors d WHERE d.user_id=?");
$stmt->execute([$_SESSION['user_id']]);
$doctor = $stmt->fetch();
$did = $doctor['id'] ?? 0;

$todayAppts = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND appointment_date=CURDATE()");
$todayAppts->execute([$did]); $todayAppts = $todayAppts->fetchColumn();

$totalPatients = $pdo->prepare("SELECT COUNT(DISTINCT patient_id) FROM appointments WHERE doctor_id=?");
$totalPatients->execute([$did]); $totalPatients = $totalPatients->fetchColumn();

$pendingAppts = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND status='pending'");
$pendingAppts->execute([$did]); $pendingAppts = $pendingAppts->fetchColumn();

$upcomingAppts = $pdo->prepare("
  SELECT a.*, u.name AS patient_name, p.blood_group, p.patient_code
  FROM appointments a
  JOIN patients p ON a.patient_id=p.id JOIN users u ON p.user_id=u.id
  WHERE a.doctor_id=? AND a.appointment_date>=CURDATE() AND a.status IN ('pending','confirmed')
  ORDER BY a.appointment_date, a.appointment_time LIMIT 8
");
$upcomingAppts->execute([$did]);
$upcoming = $upcomingAppts->fetchAll();

require_once '../includes/header.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-lg-4"><div class="stat-card"><div class="stat-icon si-blue"><i class="fa-solid fa-calendar-day"></i></div><div class="stat-num"><?= $todayAppts ?></div><div class="stat-label">Today's Appointments</div></div></div>
  <div class="col-6 col-lg-4"><div class="stat-card"><div class="stat-icon si-green"><i class="fa-solid fa-bed-pulse"></i></div><div class="stat-num"><?= $totalPatients ?></div><div class="stat-label">My Patients</div></div></div>
  <div class="col-6 col-lg-4"><div class="stat-card"><div class="stat-icon si-amber"><i class="fa-solid fa-clock"></i></div><div class="stat-num"><?= $pendingAppts ?></div><div class="stat-label">Pending Approval</div></div></div>
</div>

<div class="card">
  <div class="card-header">
    <h6 class="card-title">Upcoming Appointments</h6>
    <a href="<?= SITE_URL ?>/doctor/appointments.php" class="btn btn-sm btn-outline-primary">View All</a>
  </div>
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Patient</th><th>Code</th><th>Date</th><th>Time</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($upcoming as $a): ?>
      <tr>
        <td><div class="d-flex align-items-center gap-2"><div class="ava" style="background:var(--accent2)"><?= strtoupper(substr($a['patient_name'],0,2)) ?></div><div class="td-name"><?= clean($a['patient_name']) ?></div></div></td>
        <td><code><?= clean($a['patient_code']) ?></code></td>
        <td><?= formatDate($a['appointment_date']) ?></td>
        <td><?= formatTime($a['appointment_time']) ?></td>
        <td><?= ucfirst(str_replace('_',' ',$a['type'])) ?></td>
        <td><?= statusBadge($a['status']) ?></td>
        <td>
          <div class="d-flex gap-1">
            <a href="<?= SITE_URL ?>/doctor/appointments.php?confirm=<?= $a['id'] ?>" class="btn btn-sm btn-success"><i class="fa-solid fa-check"></i></a>
            <a href="<?= SITE_URL ?>/doctor/prescriptions.php?appt=<?= $a['id'] ?>&pid=<?= $a['patient_id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-file-prescription"></i></a>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($upcoming)): ?><tr><td colspan="7" class="text-center text-muted py-4">No upcoming appointments</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
