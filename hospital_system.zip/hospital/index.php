<?php
require_once 'includes/config.php';
if (isLoggedIn()) redirect(SITE_URL.'/'.$_SESSION['role'].'/dashboard.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND status = 'active'");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name']    = $user['name'];
        $_SESSION['email']   = $user['email'];
        $_SESSION['role']    = $user['role'];
        redirect(SITE_URL.'/'.$user['role'].'/dashboard.php');
    } else { $error = 'Invalid email or password.'; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Login — <?= SITE_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet"/>
<link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet"/>
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div class="login-logo">
      <div class="logo-icon"><i class="fa-solid fa-hospital"></i></div>
      <h2><?= SITE_NAME ?></h2>
      <p>Management System — Sign in to continue</p>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><i class="fa-solid fa-circle-exclamation me-2"></i><?= clean($error) ?></div><?php endif; ?>
    <?php if (isset($_GET['error']) && $_GET['error']==='unauthorized'): ?><div class="alert alert-warning">You are not authorized to access that page.</div><?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="your@email.com" required value="<?= clean($_POST['email']??'') ?>"/>
      </div>
      <div class="mb-4">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" required/>
      </div>
      <button type="submit" class="btn btn-primary w-100 py-2 mb-3"><i class="fa-solid fa-right-to-bracket"></i> Sign In</button>
    </form>
    <div class="mt-3 p-3 rounded-3" style="background:#f8fafc;font-size:0.78rem;color:#64748b;">
      <div class="fw-bold mb-2 text-dark">🔑 Demo Accounts (password: <code>password123</code>)</div>
      <div>👤 Admin: <code>admin@hospital.com</code></div>
      <div>🩺 Doctor: <code>doctor@hospital.com</code></div>
      <div>💊 Nurse: <code>nurse@hospital.com</code></div>
      <div>🏥 Patient: <code>patient@hospital.com</code></div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
