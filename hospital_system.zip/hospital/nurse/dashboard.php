<?php
require_once '../includes/config.php';
requireRole('nurse');
$pageTitle = 'Nurse Dashboard';

$admittedPatients = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='admitted'")->fetchColumn();
$availableRooms   = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status='available'")->fetchColumn();
$occupiedRooms    = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status='occupied'")->fetchColumn();

$patients = $pdo->query("
  SELECT p.*, u.name, u.phone, r.room_number
  FROM patients p JOIN users u ON p.user_id=u.id
  LEFT JOIN admissions a ON p.id=a.patient_id AND a.status='admitted'
  LEFT JOIN rooms r ON a.room_id=r.id
  WHERE p.status IN ('admitted','active')
  ORDER BY p.registered_at DESC LIMIT 10
")->fetchAll();

require_once '../includes/header.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-4"><div class="stat-card"><div class="stat-icon si-blue"><i class="fa-solid fa-bed-pulse"></i></div><div class="stat-num"><?= $admittedPatients ?></div><div class="stat-label">Admitted Patients</div></div></div>
  <div class="col-6 col-md-4"><div class="stat-card"><div class="stat-icon si-green"><i class="fa-solid fa-door-open"></i></div><div class="stat-num"><?= $availableRooms ?></div><div class="stat-label">Available Rooms</div></div></div>
  <div class="col-6 col-md-4"><div class="stat-card"><div class="stat-icon si-red"><i class="fa-solid fa-bed"></i></div><div class="stat-num"><?= $occupiedRooms ?></div><div class="stat-label">Occupied Rooms</div></div></div>
</div>

<div class="card">
  <div class="card-header"><h6 class="card-title">Patient Overview</h6></div>
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Patient</th><th>Phone</th><th>Room</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($patients as $p): ?>
      <tr>
        <td><div class="d-flex align-items-center gap-2"><div class="ava" style="background:var(--accent2)"><?= strtoupper(substr($p['name'],0,2)) ?></div><div class="td-name"><?= clean($p['name']) ?></div></div></td>
        <td><?= clean($p['phone'] ?? '—') ?></td>
        <td><?= clean($p['room_number'] ?? '—') ?></td>
        <td><?= statusBadge($p['status']) ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($patients)): ?><tr><td colspan="4" class="text-center text-muted py-4">No patients</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
