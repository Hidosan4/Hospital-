<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'city_hospital');
define('SITE_NAME', 'City Hospital');
define('SITE_URL', 'http://localhost/hospital');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;padding:40px;background:#fee2e2;color:#991b1b;border-radius:8px;margin:40px auto;max-width:600px;"><h2>⚠️ Database Connection Failed</h2><p>Make sure XAMPP is running and database is imported.</p><code>'.$e->getMessage().'</code></div>');
}

if (session_status() === PHP_SESSION_NONE) session_start();

function redirect($url) { header("Location: $url"); exit; }
function isLoggedIn() { return isset($_SESSION['user_id']); }
function requireLogin() { if (!isLoggedIn()) redirect(SITE_URL.'/index.php'); }
function requireRole($roles) {
    requireLogin();
    $roles = (array)$roles;
    if (!in_array($_SESSION['role'], $roles)) redirect(SITE_URL.'/index.php?error=unauthorized');
}
function clean($s) { return htmlspecialchars(strip_tags(trim($s))); }
function formatDate($d) { return $d ? date('M d, Y', strtotime($d)) : '—'; }
function formatTime($t) { return $t ? date('h:i A', strtotime($t)) : '—'; }
function statusBadge($s) {
    $m = ['active'=>'success','confirmed'=>'success','completed'=>'primary','admitted'=>'primary','paid'=>'success',
          'pending'=>'warning','processing'=>'warning','partial'=>'warning','inactive'=>'danger','cancelled'=>'danger',
          'discharged'=>'secondary','overdue'=>'danger','available'=>'success','occupied'=>'danger',
          'maintenance'=>'warning','on_leave'=>'warning','requested'=>'info'];
    $c = $m[$s] ?? 'secondary';
    return '<span class="badge bg-'.$c.'">'.ucfirst(str_replace('_',' ',$s)).'</span>';
}
?>
