<?php
$role = $_SESSION['role'] ?? '';
$name = $_SESSION['name'] ?? '';
$pageTitle = $pageTitle ?? SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title><?= clean($pageTitle) ?> — <?= SITE_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet"/>
<link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet"/>
</head>
<body>
<div class="wrapper">
<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fa-solid fa-hospital"></i></div>
    <div class="brand-text"><?= SITE_NAME ?><span><?= ucfirst($role) ?> Panel</span></div>
  </div>
  <div class="sidebar-menu">
    <?php if ($role === 'admin'): ?>
    <div class="menu-label">Main</div>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='dashboard.php')?'active':'' ?>"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
    <a href="<?= SITE_URL ?>/admin/patients.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='patients.php')?'active':'' ?>"><i class="fa-solid fa-bed-pulse"></i> Patients</a>
    <a href="<?= SITE_URL ?>/admin/doctors.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='doctors.php')?'active':'' ?>"><i class="fa-solid fa-user-doctor"></i> Doctors</a>
    <a href="<?= SITE_URL ?>/admin/nurses.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='nurses.php')?'active':'' ?>"><i class="fa-solid fa-user-nurse"></i> Nurses</a>
    <a href="<?= SITE_URL ?>/admin/appointments.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='appointments.php')?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> Appointments</a>
    <div class="menu-label">Hospital</div>
    <a href="<?= SITE_URL ?>/admin/rooms.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='rooms.php')?'active':'' ?>"><i class="fa-solid fa-door-open"></i> Rooms</a>
    <a href="<?= SITE_URL ?>/admin/medicines.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='medicines.php')?'active':'' ?>"><i class="fa-solid fa-pills"></i> Pharmacy</a>
    <a href="<?= SITE_URL ?>/admin/lab.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='lab.php')?'active':'' ?>"><i class="fa-solid fa-flask"></i> Laboratory</a>
    <a href="<?= SITE_URL ?>/admin/billing.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='billing.php')?'active':'' ?>"><i class="fa-solid fa-file-invoice-dollar"></i> Billing</a>
    <div class="menu-label">Admin</div>
    <a href="<?= SITE_URL ?>/admin/notices.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='notices.php')?'active':'' ?>"><i class="fa-solid fa-bullhorn"></i> Notices</a>

    <?php elseif ($role === 'doctor'): ?>
    <div class="menu-label">My Panel</div>
    <a href="<?= SITE_URL ?>/doctor/dashboard.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='dashboard.php')?'active':'' ?>"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
    <a href="<?= SITE_URL ?>/doctor/appointments.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='appointments.php')?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> My Appointments</a>
    <a href="<?= SITE_URL ?>/doctor/patients.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='patients.php')?'active':'' ?>"><i class="fa-solid fa-bed-pulse"></i> My Patients</a>
    <a href="<?= SITE_URL ?>/doctor/prescriptions.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='prescriptions.php')?'active':'' ?>"><i class="fa-solid fa-file-prescription"></i> Prescriptions</a>
    <a href="<?= SITE_URL ?>/doctor/lab.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='lab.php')?'active':'' ?>"><i class="fa-solid fa-flask"></i> Lab Tests</a>

    <?php elseif ($role === 'nurse'): ?>
    <div class="menu-label">My Panel</div>
    <a href="<?= SITE_URL ?>/nurse/dashboard.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='dashboard.php')?'active':'' ?>"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
    <a href="<?= SITE_URL ?>/nurse/patients.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='patients.php')?'active':'' ?>"><i class="fa-solid fa-bed-pulse"></i> Patients</a>
    <a href="<?= SITE_URL ?>/nurse/rooms.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='rooms.php')?'active':'' ?>"><i class="fa-solid fa-door-open"></i> Rooms</a>

    <?php elseif ($role === 'patient'): ?>
    <div class="menu-label">My Health</div>
    <a href="<?= SITE_URL ?>/patient/dashboard.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='dashboard.php')?'active':'' ?>"><i class="fa-solid fa-house-medical"></i> Dashboard</a>
    <a href="<?= SITE_URL ?>/patient/appointments.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='appointments.php')?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> Appointments</a>
    <a href="<?= SITE_URL ?>/patient/prescriptions.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='prescriptions.php')?'active':'' ?>"><i class="fa-solid fa-file-prescription"></i> Prescriptions</a>
    <a href="<?= SITE_URL ?>/patient/bills.php" class="menu-item <?= (basename($_SERVER['PHP_SELF'])==='bills.php')?'active':'' ?>"><i class="fa-solid fa-file-invoice-dollar"></i> My Bills</a>
    <?php endif; ?>

    <div class="menu-label">Account</div>
    <a href="<?= SITE_URL ?>/profile.php" class="menu-item"><i class="fa-solid fa-user"></i> Profile</a>
    <a href="<?= SITE_URL ?>/logout.php" class="menu-item text-danger-light"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>

<!-- MAIN -->
<div class="main-content">
<!-- TOPBAR -->
<div class="topbar">
  <button class="sidebar-toggle" id="sidebarToggle"><i class="fa-solid fa-bars"></i></button>
  <div class="topbar-title"><?= clean($pageTitle) ?></div>
  <div class="topbar-right">
    <div class="topbar-user">
      <div class="user-ava"><?= strtoupper(substr($name,0,2)) ?></div>
      <div class="user-info-top">
        <div class="user-name-top"><?= clean($name) ?></div>
        <div class="user-role-top"><?= ucfirst($role) ?></div>
      </div>
    </div>
  </div>
</div>
<!-- CONTENT START -->
<div class="content-area">
