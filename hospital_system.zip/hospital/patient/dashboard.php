<?php
require_once '../includes/config.php';
requireRole('patient');
$pageTitle = 'My Dashboard';

$stmt = $pdo->prepare("SELECT p.* FROM patients p WHERE p.user_id=?");
$stmt->execute([$_SESSION['user_id']]);
$patient = $stmt->fetch();
$pid = $patient['id'] ?? 0;

$appts = $pdo->prepare("SELECT a.*, du.name AS doctor_name, d.specialization FROM appointments a JOIN doctors d ON a.doctor_id=d.id JOIN users du ON d.user_id=du.id WHERE a.patient_id=? ORDER BY a.appointment_date DESC LIMIT 5");
$appts->execute([$pid]); $appts = $appts->fetchAll();

$prescriptions = $pdo->prepare("SELECT pr.*, du.name AS doctor_name FROM prescriptions pr JOIN doctors d ON pr.doctor_id=d.id JOIN users du ON d.user_id=du.id WHERE pr.patient_id=? ORDER BY pr.created_at DESC LIMIT 3");
$prescriptions->execute([$pid]); $prescriptions = $prescriptions->fetchAll();

$bills = $pdo->prepare("SELECT * FROM bills WHERE patient_id=? ORDER BY created_at DESC LIMIT 5");
$bills->execute([$pid]); $bills = $bills->fetchAll();

$totalAppts = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE patient_id=?");
$totalAppts->execute([$pid]); $totalAppts = $totalAppts->fetchColumn();

$pendingBills = $pdo->prepare("SELECT COUNT(*) FROM bills WHERE patient_id=? AND status='pending'");
$pendingBills->execute([$pid]); $pendingBills = $pendingBills->fetchColumn();

require_once '../includes/header.php';
?>

<!-- Welcome banner -->
<div class="card mb-4" style="background:linear-gradient(135deg,#1e3a5f,#2563eb);border:none;">
  <div class="card-body d-flex align-items-center gap-4 py-4">
    <div class="ava" style="width:60px;height:60px;font-size:1.4rem;background:rgba(255,255,255,0.2)"><?= strtoupper(substr($_SESSION['name'],0,2)) ?></div>
    <div class="text-white">
      <h5 class="mb-1 fw-bold">Welcome, <?= clean($_SESSION['name']) ?>!</h5>
      <div style="opacity:0.75;font-size:0.85rem">Patient Code: <strong><?= clean($patient['patient_code'] ?? '—') ?></strong> · Blood Group: <strong><?= clean($patient['blood_group'] ?? '—') ?></strong></div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon si-blue"><i class="fa-solid fa-calendar-check"></i></div><div class="stat-num"><?= $totalAppts ?></div><div class="stat-label">Total Appointments</div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon si-amber"><i class="fa-solid fa-file-invoice-dollar"></i></div><div class="stat-num"><?= $pendingBills ?></div><div class="stat-label">Pending Bills</div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon si-green"><i class="fa-solid fa-file-prescription"></i></div><div class="stat-num"><?= count($prescriptions) ?></div><div class="stat-label">Prescriptions</div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon si-red"><i class="fa-solid fa-heart-pulse"></i></div><div class="stat-num"><?= clean($patient['blood_group'] ?? '—') ?></div><div class="stat-label">Blood Group</div></div></div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header"><h6 class="card-title">My Appointments</h6><a href="<?= SITE_URL ?>/patient/appointments.php" class="btn btn-sm btn-outline-primary">View All</a></div>
      <div class="table-container">
        <table class="table">
          <thead><tr><th>Doctor</th><th>Date</th><th>Time</th><th>Type</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach ($appts as $a): ?>
          <tr>
            <td><div class="td-name"><?= clean($a['doctor_name']) ?></div><div class="td-sub"><?= clean($a['specialization']) ?></div></td>
            <td><?= formatDate($a['appointment_date']) ?></td>
            <td><?= formatTime($a['appointment_time']) ?></td>
            <td><?= ucfirst(str_replace('_',' ',$a['type'])) ?></td>
            <td><?= statusBadge($a['status']) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($appts)): ?><tr><td colspan="5" class="text-center text-muted py-4">No appointments yet</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card mb-3">
      <div class="card-header"><h6 class="card-title">Recent Bills</h6><a href="<?= SITE_URL ?>/patient/bills.php" class="btn btn-sm btn-outline-primary">View All</a></div>
      <div class="card-body p-0">
        <?php foreach ($bills as $b): ?>
        <div class="d-flex align-items-center justify-content-between p-3 border-bottom">
          <div><div class="td-name"><?= clean($b['invoice_number']) ?></div><div class="td-sub"><?= formatDate($b['created_at']) ?></div></div>
          <div class="text-end"><div class="fw-bold">$<?= number_format($b['total'],2) ?></div><?= statusBadge($b['status']) ?></div>
        </div>
        <?php endforeach; ?>
        <?php if (empty($bills)): ?><div class="text-center text-muted py-3">No bills yet</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
