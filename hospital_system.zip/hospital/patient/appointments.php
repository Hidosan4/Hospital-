<?php
require_once '../includes/config.php';
requireRole('patient');
$pageTitle = 'My Appointments';

$stmt = $pdo->prepare("SELECT id FROM patients WHERE user_id=?");
$stmt->execute([$_SESSION['user_id']]); $patient = $stmt->fetch(); $pid = $patient['id'] ?? 0;

// Book appointment
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $pdo->prepare("INSERT INTO appointments (patient_id,doctor_id,appointment_date,appointment_time,type,reason,status) VALUES (?,?,?,?,?,?,'pending')")
        ->execute([$pid,(int)$_POST['doctor_id'],clean($_POST['date']),clean($_POST['time']),clean($_POST['type']),clean($_POST['reason'])]);
    redirect(SITE_URL.'/patient/appointments.php?success=Appointment+booked+successfully');
}

$appts = $pdo->prepare("SELECT a.*, du.name AS doctor_name, d.specialization FROM appointments a JOIN doctors d ON a.doctor_id=d.id JOIN users du ON d.user_id=du.id WHERE a.patient_id=? ORDER BY a.appointment_date DESC");
$appts->execute([$pid]); $appts = $appts->fetchAll();

$doctors = $pdo->query("SELECT d.id, u.name, d.specialization, d.consultation_fee FROM doctors d JOIN users u ON d.user_id=u.id WHERE d.status='active'")->fetchAll();

require_once '../includes/header.php';
?>

<div class="page-header">
  <div><div class="page-title">My Appointments</div></div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookModal"><i class="fa-solid fa-plus"></i> Book Appointment</button>
</div>

<?php if (isset($_GET['success'])): ?><div class="alert alert-success"><?= clean($_GET['success']) ?></div><?php endif; ?>

<div class="card">
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Doctor</th><th>Specialization</th><th>Date</th><th>Time</th><th>Type</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($appts as $a): ?>
      <tr>
        <td><div class="td-name"><?= clean($a['doctor_name']) ?></div></td>
        <td><?= clean($a['specialization']) ?></td>
        <td><?= formatDate($a['appointment_date']) ?></td>
        <td><?= formatTime($a['appointment_time']) ?></td>
        <td><?= ucfirst(str_replace('_',' ',$a['type'])) ?></td>
        <td><?= statusBadge($a['status']) ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($appts)): ?><tr><td colspan="6" class="text-center text-muted py-4">No appointments yet. Book one!</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Book Modal -->
<div class="modal fade" id="bookModal" tabindex="-1">
  <div class="modal-dialog"><div class="modal-content border-0 rounded-4">
    <div class="modal-header border-0"><h5 class="modal-title fw-bold">Book Appointment</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <form method="POST">
        <div class="mb-3"><label class="form-label">Select Doctor *</label>
          <select name="doctor_id" class="form-select" required><option value="">Choose a doctor...</option><?php foreach($doctors as $d): ?><option value="<?= $d['id'] ?>"><?= clean($d['name']) ?> — <?= clean($d['specialization']) ?> ($<?= $d['consultation_fee'] ?>)</option><?php endforeach; ?></select>
        </div>
        <div class="row g-3 mb-3">
          <div class="col-6"><label class="form-label">Date *</label><input type="date" name="date" class="form-control" required min="<?= date('Y-m-d') ?>"/></div>
          <div class="col-6"><label class="form-label">Time *</label><input type="time" name="time" class="form-control" required/></div>
        </div>
        <div class="mb-3"><label class="form-label">Type</label>
          <select name="type" class="form-select"><option value="consultation">Consultation</option><option value="follow_up">Follow-up</option><option value="checkup">Checkup</option></select>
        </div>
        <div class="mb-3"><label class="form-label">Reason</label><textarea name="reason" class="form-control" rows="2" placeholder="Describe your symptoms..."></textarea></div>
        <div class="d-flex gap-2 justify-content-end">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-calendar-plus"></i> Book</button>
        </div>
      </form>
    </div>
  </div></div>
</div>

<?php require_once '../includes/footer.php'; ?>
