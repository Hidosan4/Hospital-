-- ============================================
-- CITY HOSPITAL MANAGEMENT SYSTEM
-- Database: city_hospital
-- ============================================

CREATE DATABASE IF NOT EXISTS city_hospital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE city_hospital;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','doctor','nurse','patient') NOT NULL,
  phone VARCHAR(20),
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE departments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  status ENUM('active','inactive') DEFAULT 'active'
);

CREATE TABLE doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  department_id INT,
  specialization VARCHAR(100),
  qualification VARCHAR(200),
  experience_years INT DEFAULT 0,
  consultation_fee DECIMAL(10,2) DEFAULT 0,
  status ENUM('active','inactive','on_leave') DEFAULT 'active',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE nurses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  department_id INT,
  shift ENUM('morning','afternoon','night') DEFAULT 'morning',
  ward VARCHAR(50),
  status ENUM('active','inactive') DEFAULT 'active',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  patient_code VARCHAR(20) UNIQUE,
  date_of_birth DATE,
  gender ENUM('male','female','other'),
  blood_group VARCHAR(5),
  address TEXT,
  emergency_contact VARCHAR(100),
  emergency_phone VARCHAR(20),
  medical_history TEXT,
  allergies TEXT,
  status ENUM('active','admitted','discharged') DEFAULT 'active',
  registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE rooms (
  id INT AUTO_INCREMENT PRIMARY KEY,
  room_number VARCHAR(20) UNIQUE NOT NULL,
  room_type ENUM('general','semi_private','private','icu','emergency') DEFAULT 'general',
  ward VARCHAR(50),
  floor INT DEFAULT 1,
  price_per_day DECIMAL(10,2) DEFAULT 0,
  status ENUM('available','occupied','maintenance') DEFAULT 'available'
);

CREATE TABLE admissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  room_id INT,
  admission_date DATE NOT NULL,
  discharge_date DATE,
  diagnosis TEXT,
  notes TEXT,
  status ENUM('admitted','discharged') DEFAULT 'admitted',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (doctor_id) REFERENCES doctors(id),
  FOREIGN KEY (room_id) REFERENCES rooms(id)
);

CREATE TABLE appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  type ENUM('consultation','follow_up','checkup','emergency') DEFAULT 'consultation',
  reason TEXT,
  notes TEXT,
  status ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE prescriptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_id INT,
  diagnosis TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE prescription_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  prescription_id INT NOT NULL,
  medicine_name VARCHAR(100) NOT NULL,
  dosage VARCHAR(50),
  frequency VARCHAR(50),
  duration VARCHAR(50),
  instructions TEXT,
  FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE
);

CREATE TABLE medicines (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50),
  unit_price DECIMAL(10,2) DEFAULT 0,
  stock_quantity INT DEFAULT 0,
  min_stock_level INT DEFAULT 10,
  expiry_date DATE,
  status ENUM('active','inactive') DEFAULT 'active'
);

CREATE TABLE lab_tests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  test_name VARCHAR(100) NOT NULL,
  result TEXT,
  result_date DATE,
  cost DECIMAL(10,2) DEFAULT 0,
  status ENUM('requested','processing','completed','cancelled') DEFAULT 'requested',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE bills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  invoice_number VARCHAR(30) UNIQUE,
  total DECIMAL(10,2) DEFAULT 0,
  paid_amount DECIMAL(10,2) DEFAULT 0,
  payment_method ENUM('cash','card','insurance','bank_transfer') DEFAULT 'cash',
  status ENUM('pending','partial','paid','overdue') DEFAULT 'pending',
  due_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE bill_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bill_id INT NOT NULL,
  description VARCHAR(200) NOT NULL,
  quantity INT DEFAULT 1,
  unit_price DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) DEFAULT 0,
  FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE
);

CREATE TABLE notices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  content TEXT,
  posted_by INT,
  target_role ENUM('all','admin','doctor','nurse','patient') DEFAULT 'all',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- ============================================
-- SEED DATA (password for all = "password123")
-- ============================================

INSERT INTO departments (name, description) VALUES
('Cardiology','Heart and cardiovascular system'),
('General Medicine','General health consultations'),
('Pediatrics','Children healthcare'),
('Orthopedics','Bone and joint care'),
('Neurology','Brain and nervous system'),
('Oncology','Cancer treatment'),
('Obstetrics','Pregnancy and childbirth'),
('Emergency','Emergency care unit');

-- password = "password123"
INSERT INTO users (name,email,password,role,phone) VALUES
('Admin User',      'admin@hospital.com',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin',  '+1-555-0001'),
('Dr. Sarah Smith', 'doctor@hospital.com',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','doctor', '+1-555-0002'),
('Nurse Maria Lopez','nurse@hospital.com',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','nurse',  '+1-555-0003'),
('James Donovan',   'patient@hospital.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','patient','+1-555-0004'),
('Dr. John Lee',    'drlee@hospital.com',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','doctor', '+1-555-0005');

INSERT INTO doctors (user_id,department_id,specialization,qualification,experience_years,consultation_fee) VALUES
(2,1,'Cardiologist','MD, FACC',12,150.00),
(5,2,'General Physician','MBBS, MD',8,80.00);

INSERT INTO nurses (user_id,department_id,shift,ward) VALUES (3,2,'morning','Ward A');

INSERT INTO patients (user_id,patient_code,date_of_birth,gender,blood_group,address,emergency_contact,emergency_phone) VALUES
(4,'P-00001','1979-06-15','male','O+','123 Main St, City','Mary Donovan','+1-555-9999');

INSERT INTO rooms (room_number,room_type,ward,floor,price_per_day,status) VALUES
('101','general','Ward A',1,50.00,'available'),
('102','general','Ward A',1,50.00,'occupied'),
('103','semi_private','Ward A',1,100.00,'available'),
('201','private','Ward B',2,200.00,'available'),
('ICU-1','icu','ICU',3,500.00,'occupied'),
('ER-1','emergency','Emergency',0,300.00,'available');

INSERT INTO medicines (name,category,unit_price,stock_quantity,min_stock_level,expiry_date) VALUES
('Paracetamol 500mg','Analgesic',0.80,320,50,'2027-03-01'),
('Amoxicillin 500mg','Antibiotic',2.40,45,50,'2026-12-01'),
('Omeprazole 20mg','Antacid',1.20,180,30,'2027-06-01'),
('Metformin 850mg','Antidiabetic',1.60,95,30,'2026-09-01');

INSERT INTO appointments (patient_id,doctor_id,appointment_date,appointment_time,type,reason,status) VALUES
(1,1,CURDATE(),'09:00:00','consultation','Chest pain check','confirmed'),
(1,1,DATE_ADD(CURDATE(),INTERVAL 7 DAY),'10:30:00','follow_up','Follow-up visit','pending');

INSERT INTO notices (title,content,posted_by,target_role) VALUES
('Welcome to City Hospital','This system helps manage all hospital operations efficiently.',1,'all');
