<?php
require_once '../includes/config.php';
requireRole('admin');
$pageTitle = 'Patients';

// Add patient
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $pdo->beginTransaction();
    try {
        $hashedPw = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO users (name,email,password,role,phone) VALUES (?,?,?,'patient',?)")
            ->execute([clean($_POST['name']), clean($_POST['email']), $hashedPw, clean($_POST['phone'])]);
        $uid = $pdo->lastInsertId();
        $code = 'P-'.str_pad($uid, 5, '0', STR_PAD_LEFT);
        $pdo->prepare("INSERT INTO patients (user_id,patient_code,date_of_birth,gender,blood_group,address,emergency_contact,emergency_phone,allergies) VALUES (?,?,?,?,?,?,?,?,?)")
            ->execute([$uid,$code,clean($_POST['dob']),clean($_POST['gender']),clean($_POST['blood_group']),clean($_POST['address']),clean($_POST['emergency_contact']),clean($_POST['emergency_phone']),clean($_POST['allergies'])]);
        $pdo->commit();
        redirect(SITE_URL.'/admin/patients.php?success=Patient+added+successfully');
    } catch (Exception $e) { $pdo->rollBack(); $error = 'Error: '.$e->getMessage(); }
}

// Delete patient
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM users WHERE id=(SELECT user_id FROM patients WHERE id=?)")->execute([(int)$_GET['delete']]);
    redirect(SITE_URL.'/admin/patients.php?success=Patient+deleted');
}

$search = clean($_GET['q'] ?? '');
$patients = $pdo->prepare("
  SELECT p.*, u.name, u.email, u.phone
  FROM patients p JOIN users u ON p.user_id=u.id
  WHERE u.name LIKE ? OR p.patient_code LIKE ? OR u.email LIKE ?
  ORDER BY p.registered_at DESC
");
$patients->execute(["%$search%", "%$search%", "%$search%"]);
$patients = $patients->fetchAll();

require_once '../includes/header.php';
?>

<div class="page-header">
  <div><div class="page-title">Patients</div><div class="page-sub"><?= count($patients) ?> patients found</div></div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fa-solid fa-plus"></i> Add Patient</button>
</div>

<?php if (isset($_GET['success'])): ?><div class="alert alert-success alert-dismissible fade show"><i class="fa-solid fa-check-circle me-2"></i><?= clean($_GET['success']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if (isset($error)): ?><div class="alert alert-danger"><?= clean($error) ?></div><?php endif; ?>

<!-- Search -->
<div class="card mb-3">
  <div class="card-body py-2">
    <form method="GET" class="d-flex gap-2">
      <input type="text" name="q" class="form-control" placeholder="Search by name, code, email..." value="<?= clean($search) ?>"/>
      <button type="submit" class="btn btn-primary px-4"><i class="fa-solid fa-search"></i></button>
      <?php if ($search): ?><a href="patients.php" class="btn btn-outline-secondary">Clear</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Patient</th><th>Code</th><th>Contact</th><th>Gender</th><th>Blood</th><th>Status</th><th>Registered</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($patients as $p): ?>
      <tr>
        <td>
          <div class="d-flex align-items-center gap-2">
            <div class="ava" style="background:var(--accent)"><?= strtoupper(substr($p['name'],0,2)) ?></div>
            <div><div class="td-name"><?= clean($p['name']) ?></div><div class="td-sub"><?= clean($p['email']) ?></div></div>
          </div>
        </td>
        <td><code><?= clean($p['patient_code']) ?></code></td>
        <td><?= clean($p['phone'] ?? '—') ?></td>
        <td><?= ucfirst($p['gender'] ?? '—') ?></td>
        <td><span class="badge bg-secondary"><?= clean($p['blood_group'] ?? '—') ?></span></td>
        <td><?= statusBadge($p['status']) ?></td>
        <td><?= formatDate($p['registered_at']) ?></td>
        <td>
          <div class="d-flex gap-1">
            <a href="<?= SITE_URL ?>/admin/patient_view.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye"></i></a>
            <a href="patients.php?delete=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this patient?')"><i class="fa-solid fa-trash"></i></a>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($patients)): ?><tr><td colspan="8" class="text-center text-muted py-4">No patients found</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Patient Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content border-0 rounded-4">
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-bold">Add New Patient</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form method="POST">
          <input type="hidden" name="action" value="add"/>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Full Name *</label><input type="text" name="name" class="form-control" required/></div>
            <div class="col-md-6"><label class="form-label">Email *</label><input type="email" name="email" class="form-control" required/></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"/></div>
            <div class="col-md-6"><label class="form-label">Password *</label><input type="password" name="password" class="form-control" required/></div>
            <div class="col-md-4"><label class="form-label">Date of Birth</label><input type="date" name="dob" class="form-control"/></div>
            <div class="col-md-4"><label class="form-label">Gender</label>
              <select name="gender" class="form-select"><option value="">Select</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select>
            </div>
            <div class="col-md-4"><label class="form-label">Blood Group</label>
              <select name="blood_group" class="form-select"><option value="">Select</option><?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bg): ?><option><?= $bg ?></option><?php endforeach; ?></select>
            </div>
            <div class="col-12"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
            <div class="col-md-6"><label class="form-label">Emergency Contact</label><input type="text" name="emergency_contact" class="form-control"/></div>
            <div class="col-md-6"><label class="form-label">Emergency Phone</label><input type="text" name="emergency_phone" class="form-control"/></div>
            <div class="col-12"><label class="form-label">Allergies</label><input type="text" name="allergies" class="form-control" placeholder="e.g. Penicillin, Aspirin"/></div>
          </div>
          <div class="d-flex gap-2 justify-content-end mt-4">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Patient</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
