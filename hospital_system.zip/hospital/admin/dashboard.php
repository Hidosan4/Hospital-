<?php
require_once '../includes/config.php';
requireRole('admin');
$pageTitle = 'Dashboard';

// Stats
$totalPatients  = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
$totalDoctors   = $pdo->query("SELECT COUNT(*) FROM doctors WHERE status='active'")->fetchColumn();
$todayAppts     = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date=CURDATE()")->fetchColumn();
$pendingBills   = $pdo->query("SELECT COUNT(*) FROM bills WHERE status='pending'")->fetchColumn();
$availableRooms = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status='available'")->fetchColumn();
$lowStock       = $pdo->query("SELECT COUNT(*) FROM medicines WHERE stock_quantity <= min_stock_level")->fetchColumn();

// Recent appointments
$recentAppts = $pdo->query("
  SELECT a.*, u.name AS patient_name, du.name AS doctor_name
  FROM appointments a
  JOIN patients p ON a.patient_id=p.id
  JOIN users u ON p.user_id=u.id
  JOIN doctors d ON a.doctor_id=d.id
  JOIN users du ON d.user_id=du.id
  ORDER BY a.created_at DESC LIMIT 6
")->fetchAll();

// Recent patients
$recentPatients = $pdo->query("
  SELECT p.*, u.name, u.email, u.phone
  FROM patients p JOIN users u ON p.user_id=u.id
  ORDER BY p.registered_at DESC LIMIT 5
")->fetchAll();

require_once '../includes/header.php';
?>

<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success alert-dismissible fade show"><i class="fa-solid fa-check-circle me-2"></i><?= clean($_GET['success']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<!-- STATS -->
<div class="row g-3 mb-4">
  <div class="col-6 col-lg-3">
    <div class="stat-card">
      <div class="stat-icon si-blue"><i class="fa-solid fa-bed-pulse"></i></div>
      <div class="stat-num"><?= $totalPatients ?></div>
      <div class="stat-label">Total Patients</div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="stat-card">
      <div class="stat-icon si-green"><i class="fa-solid fa-user-doctor"></i></div>
      <div class="stat-num"><?= $totalDoctors ?></div>
      <div class="stat-label">Active Doctors</div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="stat-card">
      <div class="stat-icon si-amber"><i class="fa-solid fa-calendar-check"></i></div>
      <div class="stat-num"><?= $todayAppts ?></div>
      <div class="stat-label">Today's Appointments</div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="stat-card">
      <div class="stat-icon si-red"><i class="fa-solid fa-door-open"></i></div>
      <div class="stat-num"><?= $availableRooms ?></div>
      <div class="stat-label">Available Rooms</div>
    </div>
  </div>
</div>

<?php if ($lowStock > 0): ?>
<div class="alert alert-warning mb-4"><i class="fa-solid fa-triangle-exclamation me-2"></i><strong><?= $lowStock ?> medicines</strong> are running low on stock. <a href="<?= SITE_URL ?>/admin/medicines.php" class="alert-link">View Pharmacy →</a></div>
<?php endif; ?>

<div class="row g-3">
  <!-- Recent Appointments -->
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header">
        <h6 class="card-title">Recent Appointments</h6>
        <a href="<?= SITE_URL ?>/admin/appointments.php" class="btn btn-sm btn-outline-primary">View All</a>
      </div>
      <div class="table-container">
        <table class="table">
          <thead><tr><th>Patient</th><th>Doctor</th><th>Date & Time</th><th>Type</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach ($recentAppts as $a): ?>
          <tr>
            <td><div class="td-name"><?= clean($a['patient_name']) ?></div></td>
            <td><?= clean($a['doctor_name']) ?></td>
            <td><?= formatDate($a['appointment_date']) ?> <?= formatTime($a['appointment_time']) ?></td>
            <td><?= ucfirst(str_replace('_',' ',$a['type'])) ?></td>
            <td><?= statusBadge($a['status']) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($recentAppts)): ?><tr><td colspan="5" class="text-center text-muted py-4">No appointments yet</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Recent Patients -->
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header">
        <h6 class="card-title">Recent Patients</h6>
        <a href="<?= SITE_URL ?>/admin/patients.php" class="btn btn-sm btn-outline-primary">View All</a>
      </div>
      <div class="card-body p-0">
        <?php foreach ($recentPatients as $p): ?>
        <div class="d-flex align-items-center gap-3 p-3 border-bottom">
          <div class="ava" style="background:var(--accent)"><?= strtoupper(substr($p['name'],0,2)) ?></div>
          <div class="flex-grow-1">
            <div class="td-name"><?= clean($p['name']) ?></div>
            <div class="td-sub"><?= clean($p['patient_code']) ?> · <?= clean($p['blood_group'] ?? '—') ?></div>
          </div>
          <?= statusBadge($p['status']) ?>
        </div>
        <?php endforeach; ?>
        <?php if (empty($recentPatients)): ?><div class="text-center text-muted py-4">No patients yet</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
