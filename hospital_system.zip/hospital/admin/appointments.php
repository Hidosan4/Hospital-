<?php
require_once '../includes/config.php';
requireRole('admin');
$pageTitle = 'Appointments';

// Add appointment
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $pdo->prepare("INSERT INTO appointments (patient_id,doctor_id,appointment_date,appointment_time,type,reason,status) VALUES (?,?,?,?,?,?,'pending')")
        ->execute([(int)$_POST['patient_id'],(int)$_POST['doctor_id'],clean($_POST['date']),clean($_POST['time']),clean($_POST['type']),clean($_POST['reason'])]);
    redirect(SITE_URL.'/admin/appointments.php?success=Appointment+booked');
}

// Update status
if (isset($_GET['status']) && isset($_GET['id'])) {
    $allowed = ['pending','confirmed','completed','cancelled'];
    if (in_array($_GET['status'], $allowed)) {
        $pdo->prepare("UPDATE appointments SET status=? WHERE id=?")->execute([clean($_GET['status']),(int)$_GET['id']]);
    }
    redirect(SITE_URL.'/admin/appointments.php?success=Status+updated');
}

$filter = clean($_GET['filter'] ?? 'all');
$sql = "SELECT a.*, u.name AS patient_name, du.name AS doctor_name, d.specialization
        FROM appointments a
        JOIN patients p ON a.patient_id=p.id JOIN users u ON p.user_id=u.id
        JOIN doctors d ON a.doctor_id=d.id JOIN users du ON d.user_id=du.id";
if ($filter !== 'all') $sql .= " WHERE a.status=".  $pdo->quote($filter);
$sql .= " ORDER BY a.appointment_date DESC, a.appointment_time DESC";
$appts = $pdo->query($sql)->fetchAll();

$patients = $pdo->query("SELECT p.id, u.name FROM patients p JOIN users u ON p.user_id=u.id ORDER BY u.name")->fetchAll();
$doctors  = $pdo->query("SELECT d.id, u.name, d.specialization FROM doctors d JOIN users u ON d.user_id=u.id WHERE d.status='active' ORDER BY u.name")->fetchAll();

require_once '../includes/header.php';
?>

<div class="page-header">
  <div><div class="page-title">Appointments</div><div class="page-sub"><?= count($appts) ?> records</div></div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fa-solid fa-plus"></i> Book Appointment</button>
</div>

<?php if (isset($_GET['success'])): ?><div class="alert alert-success alert-dismissible fade show"><i class="fa-solid fa-check-circle me-2"></i><?= clean($_GET['success']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<!-- Filter -->
<div class="d-flex gap-2 mb-3 flex-wrap">
  <?php foreach(['all','pending','confirmed','completed','cancelled'] as $f): ?>
  <a href="?filter=<?= $f ?>" class="btn btn-sm <?= $filter===$f ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= ucfirst($f) ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Type</th><th>Reason</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($appts as $a): ?>
      <tr>
        <td><div class="td-name"><?= clean($a['patient_name']) ?></div></td>
        <td><div class="td-name"><?= clean($a['doctor_name']) ?></div><div class="td-sub"><?= clean($a['specialization']) ?></div></td>
        <td><?= formatDate($a['appointment_date']) ?></td>
        <td><?= formatTime($a['appointment_time']) ?></td>
        <td><?= ucfirst(str_replace('_',' ',$a['type'])) ?></td>
        <td><span class="td-sub"><?= clean(substr($a['reason']??'',0,40)) ?><?= strlen($a['reason']??'')>40?'...':'' ?></span></td>
        <td><?= statusBadge($a['status']) ?></td>
        <td>
          <div class="dropdown">
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">Action</button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="?id=<?= $a['id'] ?>&status=confirmed">✅ Confirm</a></li>
              <li><a class="dropdown-item" href="?id=<?= $a['id'] ?>&status=completed">☑️ Complete</a></li>
              <li><a class="dropdown-item text-danger" href="?id=<?= $a['id'] ?>&status=cancelled">❌ Cancel</a></li>
            </ul>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($appts)): ?><tr><td colspan="8" class="text-center text-muted py-4">No appointments found</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
  <div class="modal-dialog"><div class="modal-content border-0 rounded-4">
    <div class="modal-header border-0"><h5 class="modal-title fw-bold">Book Appointment</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <form method="POST"><input type="hidden" name="action" value="add"/>
        <div class="mb-3"><label class="form-label">Patient *</label>
          <select name="patient_id" class="form-select" required><option value="">Select Patient</option><?php foreach($patients as $p): ?><option value="<?= $p['id'] ?>"><?= clean($p['name']) ?></option><?php endforeach; ?></select>
        </div>
        <div class="mb-3"><label class="form-label">Doctor *</label>
          <select name="doctor_id" class="form-select" required><option value="">Select Doctor</option><?php foreach($doctors as $d): ?><option value="<?= $d['id'] ?>"><?= clean($d['name']) ?> — <?= clean($d['specialization']) ?></option><?php endforeach; ?></select>
        </div>
        <div class="row g-3 mb-3">
          <div class="col-6"><label class="form-label">Date *</label><input type="date" name="date" class="form-control" required min="<?= date('Y-m-d') ?>"/></div>
          <div class="col-6"><label class="form-label">Time *</label><input type="time" name="time" class="form-control" required/></div>
        </div>
        <div class="mb-3"><label class="form-label">Type</label>
          <select name="type" class="form-select"><option value="consultation">Consultation</option><option value="follow_up">Follow-up</option><option value="checkup">Checkup</option><option value="emergency">Emergency</option></select>
        </div>
        <div class="mb-3"><label class="form-label">Reason</label><textarea name="reason" class="form-control" rows="2"></textarea></div>
        <div class="d-flex gap-2 justify-content-end">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-calendar-plus"></i> Book</button>
        </div>
      </form>
    </div>
  </div></div>
</div>

<?php require_once '../includes/footer.php'; ?>
