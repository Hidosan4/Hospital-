<?php
require_once '../includes/config.php';
requireRole('admin');
$pageTitle = 'Pharmacy';

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $pdo->prepare("INSERT INTO medicines (name,category,unit_price,stock_quantity,min_stock_level,expiry_date) VALUES (?,?,?,?,?,?)")
        ->execute([clean($_POST['name']),clean($_POST['category']),(float)$_POST['price'],(int)$_POST['stock'],(int)$_POST['min_stock'],clean($_POST['expiry'])]);
    redirect(SITE_URL.'/admin/medicines.php?success=Medicine+added');
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM medicines WHERE id=?")->execute([(int)$_GET['delete']]);
    redirect(SITE_URL.'/admin/medicines.php?success=Medicine+deleted');
}

$medicines = $pdo->query("SELECT * FROM medicines ORDER BY name")->fetchAll();
$lowStock = array_filter($medicines, fn($m) => $m['stock_quantity'] <= $m['min_stock_level']);

require_once '../includes/header.php';
?>

<div class="page-header">
  <div><div class="page-title">Pharmacy</div><div class="page-sub"><?= count($medicines) ?> medicines · <?= count($lowStock) ?> low stock</div></div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fa-solid fa-plus"></i> Add Medicine</button>
</div>

<?php if (isset($_GET['success'])): ?><div class="alert alert-success alert-dismissible fade show"><?= clean($_GET['success']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php if (!empty($lowStock)): ?><div class="alert alert-warning mb-3"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= count($lowStock) ?> medicine(s) are below minimum stock level!</div><?php endif; ?>

<div class="card">
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Medicine</th><th>Category</th><th>Stock</th><th>Unit Price</th><th>Expiry</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($medicines as $m): ?>
      <?php $isLow = $m['stock_quantity'] <= $m['min_stock_level']; ?>
      <tr <?= $isLow ? 'style="background:rgba(239,68,68,0.03)"' : '' ?>>
        <td><div class="td-name"><?= clean($m['name']) ?></div></td>
        <td><?= clean($m['category']) ?></td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <span class="fw-bold <?= $isLow ? 'text-danger' : '' ?>"><?= $m['stock_quantity'] ?></span>
            <div style="width:60px;height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden">
              <div style="height:100%;width:<?= min(($m['stock_quantity']/$m['min_stock_level'])*50,100) ?>%;background:<?= $isLow ? '#ef4444' : '#10b981' ?>;border-radius:3px"></div>
            </div>
          </div>
        </td>
        <td>$<?= number_format($m['unit_price'],2) ?></td>
        <td><?= formatDate($m['expiry_date']) ?></td>
        <td><?= $isLow ? '<span class="badge bg-danger">Low Stock</span>' : '<span class="badge bg-success">In Stock</span>' ?></td>
        <td><a href="?delete=<?= $m['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')"><i class="fa-solid fa-trash"></i></a></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1">
  <div class="modal-dialog"><div class="modal-content border-0 rounded-4">
    <div class="modal-header border-0"><h5 class="modal-title fw-bold">Add Medicine</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <form method="POST"><input type="hidden" name="action" value="add"/>
        <div class="mb-3"><label class="form-label">Medicine Name *</label><input type="text" name="name" class="form-control" required/></div>
        <div class="mb-3"><label class="form-label">Category</label><input type="text" name="category" class="form-control" placeholder="e.g. Antibiotic, Analgesic"/></div>
        <div class="row g-3 mb-3">
          <div class="col-6"><label class="form-label">Unit Price ($)</label><input type="number" name="price" class="form-control" step="0.01" min="0" value="0"/></div>
          <div class="col-6"><label class="form-label">Stock Quantity</label><input type="number" name="stock" class="form-control" min="0" value="0"/></div>
        </div>
        <div class="row g-3 mb-3">
          <div class="col-6"><label class="form-label">Min Stock Level</label><input type="number" name="min_stock" class="form-control" min="1" value="10"/></div>
          <div class="col-6"><label class="form-label">Expiry Date</label><input type="date" name="expiry" class="form-control"/></div>
        </div>
        <div class="d-flex gap-2 justify-content-end">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Add Medicine</button>
        </div>
      </form>
    </div>
  </div></div>
</div>

<?php require_once '../includes/footer.php'; ?>
