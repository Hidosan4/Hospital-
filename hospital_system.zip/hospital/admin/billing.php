<?php
require_once '../includes/config.php';
requireRole('admin');
$pageTitle = 'Billing';

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $invNum = 'INV-'.date('Ymd').'-'.rand(100,999);
    $total  = array_sum(array_map(fn($q,$p)=>$q*$p, $_POST['qty'], $_POST['price']));
    $pdo->prepare("INSERT INTO bills (patient_id,invoice_number,total,due_date,status) VALUES (?,?,?,?,?)")
        ->execute([(int)$_POST['patient_id'],$invNum,$total,clean($_POST['due_date']),'pending']);
    $bid = $pdo->lastInsertId();
    foreach ($_POST['desc'] as $i=>$desc) {
        if (trim($desc)==='') continue;
        $tot = (float)$_POST['qty'][$i]*(float)$_POST['price'][$i];
        $pdo->prepare("INSERT INTO bill_items (bill_id,description,quantity,unit_price,total) VALUES (?,?,?,?,?)")
            ->execute([$bid,clean($desc),(int)$_POST['qty'][$i],(float)$_POST['price'][$i],$tot]);
    }
    redirect(SITE_URL.'/admin/billing.php?success=Invoice+created');
}

if (isset($_GET['pay'])) {
    $pdo->prepare("UPDATE bills SET status='paid', paid_amount=total WHERE id=?")->execute([(int)$_GET['pay']]);
    redirect(SITE_URL.'/admin/billing.php?success=Bill+marked+as+paid');
}

$bills = $pdo->query("SELECT b.*, u.name AS patient_name FROM bills b JOIN patients p ON b.patient_id=p.id JOIN users u ON p.user_id=u.id ORDER BY b.created_at DESC")->fetchAll();
$patients = $pdo->query("SELECT p.id, u.name FROM patients p JOIN users u ON p.user_id=u.id ORDER BY u.name")->fetchAll();

$totalRev = $pdo->query("SELECT SUM(paid_amount) FROM bills WHERE status='paid'")->fetchColumn();
$pending  = $pdo->query("SELECT SUM(total-paid_amount) FROM bills WHERE status='pending'")->fetchColumn();

require_once '../includes/header.php';
?>

<div class="page-header">
  <div><div class="page-title">Billing</div><div class="page-sub">Invoice management</div></div>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fa-solid fa-plus"></i> New Invoice</button>
</div>

<?php if (isset($_GET['success'])): ?><div class="alert alert-success alert-dismissible fade show"><?= clean($_GET['success']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon si-green"><i class="fa-solid fa-money-bill-wave"></i></div><div class="stat-num">$<?= number_format($totalRev??0,0) ?></div><div class="stat-label">Total Revenue</div></div></div>
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon si-amber"><i class="fa-solid fa-hourglass-half"></i></div><div class="stat-num">$<?= number_format($pending??0,0) ?></div><div class="stat-label">Pending Payments</div></div></div>
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon si-blue"><i class="fa-solid fa-file-invoice"></i></div><div class="stat-num"><?= count($bills) ?></div><div class="stat-label">Total Invoices</div></div></div>
</div>

<div class="card">
  <div class="table-container">
    <table class="table">
      <thead><tr><th>Invoice #</th><th>Patient</th><th>Total</th><th>Paid</th><th>Due Date</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($bills as $b): ?>
      <tr>
        <td><code><?= clean($b['invoice_number']) ?></code></td>
        <td><div class="td-name"><?= clean($b['patient_name']) ?></div></td>
        <td><strong>$<?= number_format($b['total'],2) ?></strong></td>
        <td>$<?= number_format($b['paid_amount'],2) ?></td>
        <td><?= formatDate($b['due_date']) ?></td>
        <td><?= statusBadge($b['status']) ?></td>
        <td>
          <?php if ($b['status']!=='paid'): ?>
          <a href="?pay=<?= $b['id'] ?>" class="btn btn-sm btn-success" onclick="return confirm('Mark as paid?')"><i class="fa-solid fa-check"></i> Mark Paid</a>
          <?php else: ?>
          <span class="text-muted small">Paid</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($bills)): ?><tr><td colspan="7" class="text-center text-muted py-4">No invoices yet</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Invoice Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
  <div class="modal-dialog modal-lg"><div class="modal-content border-0 rounded-4">
    <div class="modal-header border-0"><h5 class="modal-title fw-bold">Create Invoice</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <form method="POST"><input type="hidden" name="action" value="add"/>
        <div class="row g-3 mb-3">
          <div class="col-md-8"><label class="form-label">Patient *</label>
            <select name="patient_id" class="form-select" required><option value="">Select Patient</option><?php foreach($patients as $p): ?><option value="<?= $p['id'] ?>"><?= clean($p['name']) ?></option><?php endforeach; ?></select>
          </div>
          <div class="col-md-4"><label class="form-label">Due Date</label><input type="date" name="due_date" class="form-control"/></div>
        </div>
        <div class="table-responsive">
          <table class="table table-sm" id="itemsTable">
            <thead><tr><th>Description</th><th style="width:80px">Qty</th><th style="width:110px">Unit Price</th></tr></thead>
            <tbody>
              <?php for($i=0;$i<3;$i++): ?>
              <tr><td><input type="text" name="desc[]" class="form-control form-control-sm" placeholder="Service description"/></td>
              <td><input type="number" name="qty[]" class="form-control form-control-sm" value="1" min="1"/></td>
              <td><input type="number" name="price[]" class="form-control form-control-sm" value="0" step="0.01" min="0"/></td></tr>
              <?php endfor; ?>
            </tbody>
          </table>
        </div>
        <div class="d-flex gap-2 justify-content-end mt-3">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Create Invoice</button>
        </div>
      </form>
    </div>
  </div></div>
</div>

<?php require_once '../includes/footer.php'; ?>
