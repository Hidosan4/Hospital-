# 🏥 City Hospital Management System
## Full PHP + MySQL System — XAMPP Setup Guide

---

## 📁 Folder Structure
```
hospital/
├── index.php              ← Login page
├── logout.php
├── database.sql           ← Import this first!
├── includes/
│   ├── config.php         ← DB settings here
│   ├── header.php
│   └── footer.php
├── assets/
│   ├── css/style.css
│   └── js/main.js
├── admin/
│   ├── dashboard.php
│   ├── patients.php
│   ├── doctors.php
│   ├── appointments.php
│   ├── medicines.php
│   ├── billing.php
│   └── ...
├── doctor/
│   ├── dashboard.php
│   ├── appointments.php
│   └── ...
├── nurse/
│   └── dashboard.php
└── patient/
    ├── dashboard.php
    ├── appointments.php
    └── ...
```

---

## ⚙️ STEP-BY-STEP SETUP

### Step 1 — Start XAMPP
1. Open XAMPP Control Panel
2. Start **Apache** ✅
3. Start **MySQL** ✅

### Step 2 — Copy Files
Copy the `hospital` folder to:
```
C:\xampp\htdocs\hospital\
```

### Step 3 — Import Database
1. Open browser → go to: `http://localhost/phpmyadmin`
2. Click **"New"** → create database named: `city_hospital`
3. Click on `city_hospital` database
4. Click **"Import"** tab
5. Choose file: `hospital/database.sql`
6. Click **"Go"** ✅

### Step 4 — Open the System
Go to: `http://localhost/hospital`

---

## 🔑 Demo Login Accounts
All passwords: **`password123`**

| Role    | Email                    |
|---------|--------------------------|
| Admin   | admin@hospital.com       |
| Doctor  | doctor@hospital.com      |
| Nurse   | nurse@hospital.com       |
| Patient | patient@hospital.com     |

---

## 🛠️ Configuration
Edit `includes/config.php` if needed:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');    // your MySQL username
define('DB_PASS', '');        // your MySQL password (empty for XAMPP default)
define('DB_NAME', 'city_hospital');
define('SITE_URL', 'http://localhost/hospital');
```

---

## 👥 Role Features

### 🔑 Admin
- Dashboard with live stats
- Manage Patients (add, view, delete)
- Manage Doctors & Nurses
- Appointments (book, confirm, cancel)
- Pharmacy inventory
- Lab tests
- Billing & Invoices
- Notices

### 🩺 Doctor
- View today's & upcoming appointments
- View my patients
- Write prescriptions
- Request lab tests

### 💊 Nurse
- View admitted patients
- Room/ward overview

### 🏥 Patient
- Book appointments with doctors
- View prescriptions
- View & track bills

---

## 🔒 Security Features
- Password hashing (bcrypt)
- Role-based access control
- PDO prepared statements (SQL injection protection)
- Session-based authentication
- Input sanitization

---

Built with: **PHP 8+, MySQL, Bootstrap 5, Font Awesome 6**
